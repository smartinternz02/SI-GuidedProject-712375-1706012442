
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String

import com.kms.katalon.core.testobject.TestObject



def static "example.MyKeywords.AppLogin"() {
    (new example.MyKeywords()).AppLogin()
}


def static "example.MyKeywords.Congrats"(
    	String User	) {
    (new example.MyKeywords()).Congrats(
        	User)
}


def static "com.qa.test.customFunctions.PrintHello"() {
    (new com.qa.test.customFunctions()).PrintHello()
}


def static "com.qa.test.customFunctions.PrintName"(
    	String Name	) {
    (new com.qa.test.customFunctions()).PrintName(
        	Name)
}


def static "com.qa.test.customFunctions.CheckDropDownListElementExist"(
    	TestObject object	
     , 	String option	) {
    (new com.qa.test.customFunctions()).CheckDropDownListElementExist(
        	object
         , 	option)
}
