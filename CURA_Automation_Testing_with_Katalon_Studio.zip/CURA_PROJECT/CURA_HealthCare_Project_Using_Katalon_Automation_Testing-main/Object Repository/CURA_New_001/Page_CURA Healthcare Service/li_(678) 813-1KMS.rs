<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_(678) 813-1KMS</name>
   <tag></tag>
   <elementGuidId>18719a7d-799d-43e2-b75e-0eeb18ffdcd0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.list-unstyled > li</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div/ul/li</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>9fdad508-1009-4ee9-9663-d73d40066ce9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> (678) 813-1KMS</value>
      <webElementGuid>b9b41720-1c80-4cfe-abe9-79378f40f30d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/footer[1]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-10 col-lg-offset-1 text-center&quot;]/ul[@class=&quot;list-unstyled&quot;]/li[1]</value>
      <webElementGuid>1abc55bd-d36d-4a15-a19e-9687976dc5ed</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li</value>
      <webElementGuid>3f875c0f-17f9-4c50-a47f-c0a1a4000493</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = ' (678) 813-1KMS' or . = ' (678) 813-1KMS')]</value>
      <webElementGuid>6f020563-a4aa-4cca-9560-18598f2136d3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
