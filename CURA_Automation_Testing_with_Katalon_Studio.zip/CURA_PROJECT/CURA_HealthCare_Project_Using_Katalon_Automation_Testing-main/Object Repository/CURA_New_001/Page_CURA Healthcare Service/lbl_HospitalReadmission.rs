<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_HospitalReadmission</name>
   <tag></tag>
   <elementGuidId>398ef067-e94a-462f-9bc6-edd1c85f33e2</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>hospital_readmission</value>
      <webElementGuid>0f930813-6b12-4449-b960-a8bfa0798516</webElementGuid>
   </webElementProperties>
</WebElementEntity>
