<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_Comment</name>
   <tag></tag>
   <elementGuidId>91e56a4b-056f-4fe3-8f3d-02e0435189af</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>comment</value>
      <webElementGuid>c5b8632b-a857-4199-8b39-ebc1851c5d77</webElementGuid>
   </webElementProperties>
</WebElementEntity>
