<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_Program</name>
   <tag></tag>
   <elementGuidId>5466305b-f953-4812-b2b3-51f789993da2</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>program</value>
      <webElementGuid>eedfb814-febd-4213-bdec-6907e4ec3380</webElementGuid>
   </webElementProperties>
</WebElementEntity>
