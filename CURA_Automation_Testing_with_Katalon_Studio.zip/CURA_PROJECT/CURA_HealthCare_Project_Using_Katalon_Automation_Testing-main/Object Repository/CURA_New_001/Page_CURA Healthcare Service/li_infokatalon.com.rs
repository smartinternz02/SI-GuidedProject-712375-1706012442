<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_infokatalon.com</name>
   <tag></tag>
   <elementGuidId>c79c270c-58cb-43ce-8c4f-f7a81fdcd7da</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>ul.list-unstyled > li:nth-of-type(2)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div/ul/li[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>8aa28640-2945-438e-abba-8fb3c7e60c32</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> info@katalon.com
                    </value>
      <webElementGuid>6238f5fe-6d99-4a61-a539-d43f0a265e5e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/footer[1]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-10 col-lg-offset-1 text-center&quot;]/ul[@class=&quot;list-unstyled&quot;]/li[2]</value>
      <webElementGuid>6c27c3d9-8d73-4e51-99ad-1846790a3636</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li[2]</value>
      <webElementGuid>7904dc1a-aaed-4b30-a352-40fdd0438c6f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = ' info@katalon.com
                    ' or . = ' info@katalon.com
                    ')]</value>
      <webElementGuid>9eccda9c-c5e3-437b-b323-15d4f1355b5e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
