<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_Facility</name>
   <tag></tag>
   <elementGuidId>d64ddfbf-b5c8-4b76-b16b-badaadbabb3a</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>facility</value>
      <webElementGuid>3b5e1797-e003-4d0f-90ec-01f351021926</webElementGuid>
   </webElementProperties>
</WebElementEntity>
