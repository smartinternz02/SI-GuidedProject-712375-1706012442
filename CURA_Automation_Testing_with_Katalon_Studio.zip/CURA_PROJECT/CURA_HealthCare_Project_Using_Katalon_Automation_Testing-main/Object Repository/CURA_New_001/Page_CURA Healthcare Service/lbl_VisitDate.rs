<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lbl_VisitDate</name>
   <tag></tag>
   <elementGuidId>b4a2006e-72d8-49b0-9972-0207f9a9e993</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>visit_date</value>
      <webElementGuid>b78d2684-47b2-4d12-8406-a675721d48e6</webElementGuid>
   </webElementProperties>
</WebElementEntity>
