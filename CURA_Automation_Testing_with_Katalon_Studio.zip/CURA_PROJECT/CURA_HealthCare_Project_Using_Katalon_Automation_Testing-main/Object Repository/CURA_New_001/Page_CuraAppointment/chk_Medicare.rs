<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>chk_Medicare</name>
   <tag></tag>
   <elementGuidId>1c8dffd8-0946-4c2e-8a1b-061864f27abe</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>radio_program_medicare</value>
      <webElementGuid>3c0143d0-fc5e-465f-88b9-8daed6823090</webElementGuid>
   </webElementProperties>
</WebElementEntity>
