<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_Comment</name>
   <tag></tag>
   <elementGuidId>31e92a03-7d47-46a6-91f3-52f0a34fd9e7</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>txt_comment</value>
      <webElementGuid>bb436731-2234-412b-85c5-00d4176f684a</webElementGuid>
   </webElementProperties>
</WebElementEntity>
