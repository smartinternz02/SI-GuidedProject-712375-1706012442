<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_BookAppointment</name>
   <tag></tag>
   <elementGuidId>6f44f04e-d8f2-4ac2-a075-86c174fbe3f1</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>btn-book-appointment</value>
      <webElementGuid>987ff087-93bd-4026-922b-d9ce37fa187b</webElementGuid>
   </webElementProperties>
</WebElementEntity>
