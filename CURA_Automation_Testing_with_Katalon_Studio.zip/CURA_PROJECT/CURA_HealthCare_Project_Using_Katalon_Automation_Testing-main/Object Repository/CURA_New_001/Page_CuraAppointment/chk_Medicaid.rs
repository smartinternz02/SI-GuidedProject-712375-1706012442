<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>chk_Medicaid</name>
   <tag></tag>
   <elementGuidId>156da0a2-37ea-473a-b6c0-781c98105883</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>radio_program_medicaid</value>
      <webElementGuid>05ef0181-b421-4691-b348-b028cd97545a</webElementGuid>
   </webElementProperties>
</WebElementEntity>
