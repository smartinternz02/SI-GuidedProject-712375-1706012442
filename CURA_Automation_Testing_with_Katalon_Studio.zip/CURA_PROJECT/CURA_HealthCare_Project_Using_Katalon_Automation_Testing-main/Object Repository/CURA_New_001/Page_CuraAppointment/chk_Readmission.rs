<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>chk_Readmission</name>
   <tag></tag>
   <elementGuidId>3bad564a-0f85-4f9d-ad40-c927913d2bb3</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>hospital_readmission</value>
      <webElementGuid>2f83364d-5c21-4556-a858-26180f58d541</webElementGuid>
   </webElementProperties>
</WebElementEntity>
