<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_VisitDate</name>
   <tag></tag>
   <elementGuidId>ca3e611c-2b58-4865-87ba-7e39a4fdd2f3</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>txt_visit_date</value>
      <webElementGuid>b6c988a6-74b8-4cf7-9f59-9694ba6d9335</webElementGuid>
   </webElementProperties>
</WebElementEntity>
