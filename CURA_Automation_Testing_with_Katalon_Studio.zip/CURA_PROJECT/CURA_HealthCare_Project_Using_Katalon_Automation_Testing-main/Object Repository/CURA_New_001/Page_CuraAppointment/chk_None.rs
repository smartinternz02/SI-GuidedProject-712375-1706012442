<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>chk_None</name>
   <tag></tag>
   <elementGuidId>a6eb43b7-e369-4b9d-a795-4aac97c1b86e</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>radio_program_none</value>
      <webElementGuid>4efd0a0e-72df-4411-9ad1-fe697a2b989f</webElementGuid>
   </webElementProperties>
</WebElementEntity>
