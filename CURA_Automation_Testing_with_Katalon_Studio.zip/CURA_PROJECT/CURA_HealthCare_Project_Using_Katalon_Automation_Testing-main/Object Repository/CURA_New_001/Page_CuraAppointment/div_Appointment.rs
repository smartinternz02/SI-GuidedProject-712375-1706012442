<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Appointment</name>
   <tag></tag>
   <elementGuidId>99e25e94-1695-43da-97f8-5737ac74d9f5</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>appointment</value>
      <webElementGuid>94d7ff80-d79d-4d97-bc5a-b02147d6cc19</webElementGuid>
   </webElementProperties>
</WebElementEntity>
