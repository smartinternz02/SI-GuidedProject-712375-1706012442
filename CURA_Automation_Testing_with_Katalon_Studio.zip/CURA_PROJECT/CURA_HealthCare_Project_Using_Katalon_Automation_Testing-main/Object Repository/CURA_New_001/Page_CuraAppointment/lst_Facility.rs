<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lst_Facility</name>
   <tag></tag>
   <elementGuidId>f8501180-53f2-4f69-97e9-4c537b723213</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>combo_facility</value>
      <webElementGuid>1245db8a-96d1-454b-b115-ffabee5e0c8d</webElementGuid>
   </webElementProperties>
</WebElementEntity>
