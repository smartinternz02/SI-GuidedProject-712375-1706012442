<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_16012024                               _ef059d</name>
   <tag></tag>
   <elementGuidId>88c687f9-6270-4e94-b814-0faca953d241</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='history']/div/div[2]/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>4d741a30-6802-420a-8a59-dc4829a1a700</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value> col-sm-offset-2 col-sm-8</value>
      <webElementGuid>d4943075-f854-4b5c-bc50-b4cdc6b13a7f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    16/01/2024
                    
                        
                            Facility
                        
                        
                            Hongkong CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            Yes
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicaid
                        
                        

                        
                            Comment
                        
                        
                            Testing 
                        
                    
                
            </value>
      <webElementGuid>ac666fc2-ceda-4077-ac77-894f883e2b89</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;history&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-offset-2 col-sm-8&quot;]</value>
      <webElementGuid>f2c53bf1-0fc3-4d6e-9c6f-1029b10a0a33</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='history']/div/div[2]/div</value>
      <webElementGuid>8abe44b6-8955-4406-bc36-e23fd0cfd4ab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div</value>
      <webElementGuid>95f1f485-f391-4426-b2fb-c07ae013b09f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                
                    16/01/2024
                    
                        
                            Facility
                        
                        
                            Hongkong CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            Yes
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicaid
                        
                        

                        
                            Comment
                        
                        
                            Testing 
                        
                    
                
            ' or . = '
                
                    16/01/2024
                    
                        
                            Facility
                        
                        
                            Hongkong CURA Healthcare Center
                        
                        

                        
                            Apply for hospital readmission
                        
                        
                            Yes
                        
                        

                        
                            Healthcare Program
                        
                        
                            Medicaid
                        
                        

                        
                            Comment
                        
                        
                            Testing 
                        
                    
                
            ')]</value>
      <webElementGuid>44ac6a61-de8e-4211-b929-61c5ba6b4f71</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
