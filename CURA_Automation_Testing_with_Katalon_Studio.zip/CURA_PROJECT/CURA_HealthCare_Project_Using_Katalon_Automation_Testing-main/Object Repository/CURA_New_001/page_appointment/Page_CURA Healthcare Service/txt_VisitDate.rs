<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_VisitDate</name>
   <tag></tag>
   <elementGuidId>5e0fa1ee-ebd4-40c2-830a-2ee03cb8cb6d</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>txt_visit_date</value>
      <webElementGuid>0ba00234-9224-4759-9032-e8c592b6a6c5</webElementGuid>
   </webElementProperties>
</WebElementEntity>
