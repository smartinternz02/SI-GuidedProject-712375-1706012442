<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Appointment Confirmation               _7d61e7</name>
   <tag></tag>
   <elementGuidId>6c0e501f-d054-498e-b46b-9cea1af6dbb4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='summary']/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.row</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>3fae483c-3150-49b3-8c5e-5a34db4d9a05</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>row</value>
      <webElementGuid>fbf76385-732b-4f73-b1ec-062a90388dd6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            
                Appointment Confirmation
                Please be informed that your appointment has been booked as following:
                
            
            
                
                    Facility
                
                
                    Hongkong CURA Healthcare Center
                
            
            
                
                    Apply for hospital readmission
                
                
                    Yes
                
            
            
                
                    Healthcare Program
                
                
                    Medicaid
                
            
            
                
                    Visit Date
                
                
                    17/01/2024
                
            
            
                
                    Comment
                
                
                    Testing
                
            
            
                Go to Homepage
            
        </value>
      <webElementGuid>44d949f6-1d3e-461c-b472-fe8950a82c2a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;summary&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]</value>
      <webElementGuid>a96569bb-8c22-4f5a-ae4a-01adea970c10</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='summary']/div/div</value>
      <webElementGuid>9af42c06-21c8-42a8-a778-7c306b8c082f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div</value>
      <webElementGuid>e9ade8b1-75a4-4ec6-b3b4-fb7c5ae683e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
            
                Appointment Confirmation
                Please be informed that your appointment has been booked as following:
                
            
            
                
                    Facility
                
                
                    Hongkong CURA Healthcare Center
                
            
            
                
                    Apply for hospital readmission
                
                
                    Yes
                
            
            
                
                    Healthcare Program
                
                
                    Medicaid
                
            
            
                
                    Visit Date
                
                
                    17/01/2024
                
            
            
                
                    Comment
                
                
                    Testing
                
            
            
                Go to Homepage
            
        ' or . = '
            
                Appointment Confirmation
                Please be informed that your appointment has been booked as following:
                
            
            
                
                    Facility
                
                
                    Hongkong CURA Healthcare Center
                
            
            
                
                    Apply for hospital readmission
                
                
                    Yes
                
            
            
                
                    Healthcare Program
                
                
                    Medicaid
                
            
            
                
                    Visit Date
                
                
                    17/01/2024
                
            
            
                
                    Comment
                
                
                    Testing
                
            
            
                Go to Homepage
            
        ')]</value>
      <webElementGuid>aa6ca169-1f67-4818-8016-57ab521747f0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
