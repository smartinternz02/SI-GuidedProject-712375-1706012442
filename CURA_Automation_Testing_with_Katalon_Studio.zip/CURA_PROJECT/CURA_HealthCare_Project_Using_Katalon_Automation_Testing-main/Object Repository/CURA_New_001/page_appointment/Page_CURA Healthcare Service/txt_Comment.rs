<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_Comment</name>
   <tag></tag>
   <elementGuidId>d0699ee7-8b3f-448a-b337-fba014884aac</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>txt_comment</value>
      <webElementGuid>19a839a0-55a1-4c64-a398-bbfa52dfc2cb</webElementGuid>
   </webElementProperties>
</WebElementEntity>
