<?xml version="1.0" encoding="UTF-8"?>
<FilteringTestSuiteEntity>
   <description>Allow user to create dynamic test suite</description>
   <name>DTS_001_Appointment</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>328d2176-2954-4802-ae08-86aa90d444c5</testSuiteGuid>
   <filteringBuiltIn>com.kms.katalon.execution.platform.DynamicBuiltInSearch</filteringBuiltIn>
   <filteringExtension></filteringExtension>
   <filteringPlugin></filteringPlugin>
   <filteringText>tag=(smoke) </filteringText>
</FilteringTestSuiteEntity>
